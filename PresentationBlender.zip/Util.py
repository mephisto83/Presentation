

debugmode = True
def debugPrint(val=None):
    if debugmode and val:
        print(val)
